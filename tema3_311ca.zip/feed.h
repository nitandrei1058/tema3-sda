#ifndef FEED_H
#define FEED_H

#include "friends.h"
#include "posts.h"
#include "users.h"
#include "utils_posts.h"

/**
 * Function that handles the calling of every command from task 3
 *
 * Please add any necessary parameters to the functions
*/
void handle_input_feed(char *input, int **friendship, tree_t *posts);

#endif // FEED_H
