#ifndef POSTS_H
#define POSTS_H

#include "utils_posts.h"

/**
 * Function that handles the calling of every command from task 2
 *
 * Please add any necessary parameters to the functions
 */
void handle_input_posts(char *input, tree_t *posts);

#endif // POSTS_H
